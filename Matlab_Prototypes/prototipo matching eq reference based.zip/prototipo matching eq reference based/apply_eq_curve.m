function target_processed = apply_eq_curve(target, Fs, fc, eq_curve_dB)
    nBands = numel(fc); %numero di filtri
    Q = 4;              %Q standard per tutti i filtri

    %inizializzo il segnale elaborato
    target_processed = zeros(size(target));

    %applico ciascun filtro con il gain specificato dalla curva
    for k = 1:nBands
        %calcolo i coefficienti biquad con il gain dalla curva
        [b, a] = getBiquadCoeff('BP1', Fs, fc(k), Q, eq_curve_dB(k));
        
        %applico il filtro
        y = filter(b, a, target);
        
        %sommo l'output filtrato al segnale finale
        target_processed = target_processed + y;
    end
    %normalizzo per evitare clipping
    target_processed = target_processed / max(abs(target_processed));
end
