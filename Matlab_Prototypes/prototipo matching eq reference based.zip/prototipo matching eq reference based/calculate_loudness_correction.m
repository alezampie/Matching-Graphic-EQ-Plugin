function gain_dB = calculate_loudness_correction(reference, Fs_ref, target, Fs_target)
    L_reference    = integratedLoudness(reference, Fs_ref);
    L_target = integratedLoudness(target, Fs_target);
    
    gain_dB = L_reference - L_target;
end

