function analysis = create_analysis_filterbank(signal, Fs, fc)
    nBands = numel(fc);
    Q = 4;  %Q factor standard

    analysis = zeros(nBands,1);

    for k = 1:nBands
        %genero i coefficienti del filtro biquad
        [b, a] = getBiquadCoeff('BP1', Fs, fc(k), Q, 0);

        %applico il filtro
        y = filter(b, a, signal);

        %calcolo RMS per ciascun filtro
        analysis(k) = rms(y);
    end
end
