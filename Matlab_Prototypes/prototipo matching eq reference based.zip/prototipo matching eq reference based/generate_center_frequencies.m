function fc = generate_center_frequencies(scaleType, nBands, fMin, fMax)
    switch lower(scaleType)
        case 'linear'
            fc = linspace(fMin, fMax, nBands);
    
        case 'mel'
            melMin = hz2mel(fMin);
            melMax = hz2mel(fMax);
            fc_mel = linspace(melMin, melMax, nBands);
            fc = mel2hz(fc_mel);
    
        case 'semitones'
            nSteps = nBands - 1;
            fc = fMin * 2.^((0:nSteps) * (log2(fMax/fMin)/nSteps));
    
            case 'erb'
            erbMin = hz2erbs(fMin);
            erbMax = hz2erbs(fMax);
            fc_erb = linspace(erbMin, erbMax, nBands);
            fc = ERB2hz(fc_erb);
    
        case 'bark'
            barkMin = hz2bark(fMin);
            barkMax = hz2bark(fMax);
            fc_bark = linspace(barkMin, barkMax, nBands);
            fc = bark2hz(fc_bark);
            
        otherwise
            error('Tipo di scala non riconosciuto');
    end
end
