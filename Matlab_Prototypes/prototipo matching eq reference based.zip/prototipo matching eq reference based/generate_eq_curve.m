function eq_curve_dB = generate_eq_curve(target_analysis, reference_analysis, maxGain)
    %calcolo la differenza RMS tra target e reference
    epsilon = 1e-12; %per evitare divisioni per zero
    eq_curve_dB = 20*log10(reference_analysis ./ (target_analysis + epsilon));


    %applico il limite massimo/minimo di guadagno
    eq_curve_dB(eq_curve_dB > maxGain)  = maxGain;
    eq_curve_dB(eq_curve_dB < -maxGain) = -maxGain;
end
