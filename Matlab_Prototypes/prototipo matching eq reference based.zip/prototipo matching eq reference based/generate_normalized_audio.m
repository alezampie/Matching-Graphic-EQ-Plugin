function audio_norm = generate_normalized_audio(audio)
    epsilon = 1e-12;
    audio_norm = zeros(size(audio));
    
    for ch = 1:size(audio,2)
        rms_val = rms(audio(:,ch));
        audio_norm(:,ch) = audio(:,ch) / (rms_val + epsilon);
    end
end
