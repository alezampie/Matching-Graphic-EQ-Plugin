clear; close all; clc;
addpath(genpath('library/LIM-Toolbox-master'));

%MACRO IMPORTANTI
nBands   = 32;          %numero filtri
scale    = 'semitones';      %linear, mel, semitones, bark, erb
fLow     = 50;         %limite inferiore
fHigh    = 18000;      %limite superiore


audioDir = 'audio';

%CERCO I FILE
fileTarget = 'target.wav';
fileRef    = 'reference.wav';

%LI CARICO
[target, Fs_target] = audioread(fullfile(audioDir, fileTarget));
[ref,    Fs_ref]    = audioread(fullfile(audioDir, fileRef));

%CONTROLLO CHE I SEGNALI SIANO STEREO
if size(target,2) == 1
    target = [target target];
end

if size(ref,2) == 1
    ref = [ref ref];
end

%ALLINEO LA REFERENCE AL TARGET PER SICUREZZA
[ref_aligned, lag, s] = alignvector(ref, target);

%NORMALIZZO
target_norm = generate_normalized_audio(target);
ref_norm    = generate_normalized_audio(ref_aligned);

%FACCIO CONVERSIONE DA STEREO A MID/SIDE, sia target che reference
target_M = (target_norm(:,1) + target_norm(:,2)) / sqrt(2);
target_S = (target_norm(:,1) - target_norm(:,2)) / sqrt(2);

ref_M = (ref_norm(:,1) + ref_norm(:,2)) / sqrt(2);
ref_S = (ref_norm(:,1) - ref_norm(:,2)) / sqrt(2);

%GENERO LE FREQUENCE CENTRALI CHE DEVE AVERE OGNI FILTRO
fc = generate_center_frequencies(scale, nBands, fLow, fHigh);

%FACCIO L'ANALISI DELLA REFERENCE E DEL TARGET USANDO FILTRI BIQUAD
analysis_target_M = create_analysis_filterbank(target_M, Fs_target, fc);
analysis_target_S = create_analysis_filterbank(target_S, Fs_target, fc);

analysis_ref_M = create_analysis_filterbank(ref_M, Fs_ref, fc);
analysis_ref_S = create_analysis_filterbank(ref_S, Fs_ref, fc);

%CREO LA CURVE DI EQUALIZZAZIONE
eq_curve_dB_M = generate_eq_curve(analysis_target_M, analysis_ref_M, 12);
eq_curve_dB_S = generate_eq_curve(analysis_target_S, analysis_ref_S, 12);

%LA VISUALIZZO
figure;
subplot(2,1,1);
bar(eq_curve_dB_M);
xlabel('Banda filtro');
ylabel('Gain (dB)');
title('Curva di Equalizzazione - Mid');
grid on;

subplot(2,1,2);
bar(eq_curve_dB_S);
xlabel('Banda filtro');
ylabel('Gain (dB)');
title('Curva di Equalizzazione - Side');
grid on;

%APPLICO L'EQUALIZZAZIONE
target_M_eq = apply_eq_curve(target_M, Fs_target, fc, eq_curve_dB_M);
target_S_eq = apply_eq_curve(target_S, Fs_target, fc, eq_curve_dB_S);

%RICOMBINO E PASSO DA MID/SIDE A STEREO
target_processed = zeros(size(target));
target_processed(:,1) = (target_M_eq + target_S_eq) / sqrt(2);
target_processed(:,2) = (target_M_eq - target_S_eq) / sqrt(2);

%CALCOLO LA CORREZIONE LOUDNESS
gain_dB = calculate_loudness_correction(ref_aligned, Fs_ref, target_processed, Fs_target);

%APPLICO LA CORREZIONE AL SEGNALE
%in questo caso, non avendo un segnale real time a cui applicare la curva
%di equalizzazione e la correzione, uso direttamente "target_processed"
%è già equalizzato e applico solo la correzione loudness

target_processed = target_processed * 10^(gain_dB/20);

%ASCOLTO
sound(target_processed, Fs_target);