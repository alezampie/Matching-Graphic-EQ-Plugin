clear; close all; clc;
addpath(genpath('library/LIM-Toolbox-master'));

%MACRO IMPORTANTI
nBands   = 16;          %numero filtri
scale    = 'semitones';      %linear, mel, semitones, bark, erb
fLow     = 50;         %limite inferiore
fHigh    = 18000;      %limite superiore


audioDir = 'audio';

%CERCO I FILE
fileTarget = 'raw_example.wav';
fileRef    = 'reference.wav';

%LI CARICO
[target, Fs_target] = audioread(fullfile(audioDir, fileTarget));
[ref,    Fs_ref]    = audioread(fullfile(audioDir, fileRef));

%CONTROLLO CHE I SEGNALI SIANO STEREO per standardizzare il processo
if size(target,2) == 1
    target = [target target];
end

if size(ref,2) == 1
    ref = [ref ref];
end

%ALLINEO LA REFERENCE AL TARGET PER SICUREZZA
[ref_aligned, lag, s] = alignvector(ref, target);

%FACCIO CONVERSIONE DA STEREO A MONO
target_mono = mean(target, 2);
ref_mono    = mean(ref_aligned, 2);

%NORMALIZZO
target_norm = generate_normalized_audio(target_mono);
ref_norm    = generate_normalized_audio(ref_mono);

%GENERO LE FREQUENCE CENTRALI CHE DEVE AVERE OGNI FILTRO
fc = generate_center_frequencies(scale, nBands, fLow, fHigh);

%FACCIO L'ANALISI DELLA REFERENCE E DEL TARGET USANDO FILTRI BIQUAD
analysis_target = create_analysis_filterbank(target_norm, Fs_target, fc);
analysis_ref    = create_analysis_filterbank(ref_norm, Fs_ref, fc);

%CREO LA CURVA DI EQUALIZZAZIONE
eq_curve_dB = generate_eq_curve(analysis_target, analysis_ref, 12);

%LA VISUALIZZO
figure;
bar(eq_curve_dB);
xlabel('Banda');
ylabel('Gain (dB)');
title('Curva di Equalizzazione (Mono-based)');
grid on;

%APPLICO L'EQUALIZZAZIONE
target_L_eq = apply_eq_curve(target(:,1), Fs_target, fc, eq_curve_dB);
target_R_eq = apply_eq_curve(target(:,2), Fs_target, fc, eq_curve_dB);

%PASSO DA MONO A STEREO
target_processed = [target_L_eq target_R_eq];

%CALCOLO LA CORREZIONE LOUDNESS
gain_dB = calculate_loudness_correction(ref_aligned, Fs_ref, target_processed, Fs_target);

%APPLICO LA CORREZIONE AL SEGNALE
%in questo caso, non avendo un segnale real time a cui applicare la curva
%di equalizzazione e la correzione, uso direttamente "target_processed"
%è già equalizzato e applico solo la correzione loudness

target_processed = target_processed * 10^(gain_dB/20);

%ASCOLTO
sound(target_processed, Fs_target);
